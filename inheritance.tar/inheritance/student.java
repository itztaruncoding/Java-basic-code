package com.inheritance;

public class student extends empolyee


{
	
	 String name;
	 String roll_no;
	 String dept;
	public void Student_info(
	 String name,String roll_no,
	 String dept) {
		System.out.println("student name"+name);
    	System.out.println("student Roll_no"+roll_no);
    	System.out.println("student dept"+dept);
	}

}
