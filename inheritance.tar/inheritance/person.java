package com.inheritance;

public class person {
            public void person_info(String name , int id, String city) {
            	System.out.println("person name"+name);
            	System.out.println("person id"+id);
            	System.out.println("person city"+city);
            }
}
