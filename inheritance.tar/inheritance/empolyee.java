package com.inheritance;

public class empolyee extends person {
             public void empolyee_info(String name,String city,String sal){
            	 
            	 System.out.println("empolyee name"+name);
             	System.out.println("empolyee id"+sal);
             	System.out.println("empolyee city"+city);
             }
}
