package com.inheritance;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student st = new student();
		 Scanner sc = new Scanner(System.in);
		  System.out.println("your are 1.student ,2.person,3.empolyee ? \n type here number");
		  int you = sc.nextInt(); 
		  if (you==1 ) {
        
       
        System.out.println("enter student details 1. name, 2 roll_no,3 department");
       
        String a = sc.nextLine();
        System.out.println(" 2 roll_no");
        String b = sc.nextLine();
        System.out.println("3 department");
        String c = sc.nextLine();
        st.Student_info(a, b, c);
		  }
		  if (you==2 ) {
		        
		       
		        System.out.println("enter person details 1. name, 2 id ,3 city");
		       
		        String a = sc.nextLine();
		        System.out.println(" 2 id ");
		        int b = sc.nextInt();
		        System.out.println("3 city");
		        String c = sc.nextLine();
		        st.person_info(a, b, c);
				  }
		  
		  if (you==3) {
		        
		       
		        System.out.println("enter student details 1. name, 2 sal ,3 city");
		       
		        String a = sc.nextLine();
		        System.out.println(" 2 sal ");
		        String b = sc.next();
		        System.out.println("3 city");
		        String c = sc.nextLine();
		        st.empolyee_info(a, b, c);
				  }
        
	}

}
