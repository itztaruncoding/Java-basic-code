package com.exception;

import java.util.Scanner;

public class leapyear extends Exception {
	leapyear(String msg){
		super(msg);
	}
	  static void validleapyear(int leapyear) throws leapyear{
		  if(leapyear%4!=0) {
			  if(leapyear%100!=0) {
				  
			  
			  throw new leapyear("this is not  leap year");
		  }
		  }
		  else {
			  System.out.println("this is   leap year");
		  }
		  
	  }
 

	  public static void main(String[] args) {
		  Scanner sc=new Scanner(System.in);
		  System.out.println("enter year");
		  int a=sc.nextInt();
		  
			 try {
				 validleapyear(a);
			 }
			 catch(leapyear e) {
              System.out.println("exception is occered");				 
			 }
	  }
}
	