package tightcoupling;

public class magine {
	public void read() {
		System.out.println("reading magine");
	}
}
