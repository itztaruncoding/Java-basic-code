package tightcoupling;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            library l = new library();
            l.library_info();
	}

}
