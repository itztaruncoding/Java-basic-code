package tightcoupling;

public class books {
	public void read() {
		System.out.println("reading books");
	}

}
