package tightcoupling;

public class library {
	books b;
	library(){
		b=new books();
	}
	public void library_info() {
		System.out.println("welcome to library");
		b.read();
		
	}
	

}
