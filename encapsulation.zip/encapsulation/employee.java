package com.encapsulation;

public class employee {
	private String hello;
        protected void email() {
		System.out.println("your email is ");
	}
	public String gethello() {
		return hello;
	}
	public void sethello(String hello) {
	
	this.hello=hello;
	}
	

}
