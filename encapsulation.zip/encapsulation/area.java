package com.encapsulation;
import java.util.Scanner;
public class area {
 private double pi = 3.14;
 public void circle(double r) {
	 double ac=pi*r*r;
	 System.out.println(ac);
 }
 public static void main(String[] args) {
	 System.out.println("enter radius of circle");
	 Scanner sc =new Scanner (System.in);
	 double r =sc.nextDouble(); 
	 area a =new area();
	 a.circle(r);
 }
}
