package com.encapsulation;

public class rectangle {
           protected int length = 2;
           protected int breath = 3;
       
	

}
