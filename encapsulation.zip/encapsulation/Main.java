package com.encapsulation;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        employee e = new employee();
        e.sethello("tarun");
        System.out.println(e.gethello());
	}

}
