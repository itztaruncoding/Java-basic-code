package com.encapsulation;

import java.util.Scanner;

public class person {
	private int age =0 ;
	 public void setAge(int age) {
		    this.age = age;
		  }
	
	public void per() {
		if(age<=24) {
			System.out.println("you are elgiable");
		}
		else {
			System.out.println("you are not elgiable");
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter age");
		 Scanner sc =new Scanner (System.in);
		 int age =sc.nextInt();
		 person p  = new person();
		 p.setAge(age);
		 p.per();
	}

}
