package com.labs;

import java.util.Scanner;

public class year {
	public static void main(String[]args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("enter year");
		int y = sc.nextInt();
		if(y%4==0) {
			System.out.println("this year "+y+" is a leap year");
		}
		else if(y%400==0) {
			System.out.println("this year "+y+" is a leap year");
		}
		else {
			System.out.println("this year "+y+" is a leap year");
		}
	}

}
