package com.labs;

 
 class Manali extends Hillstation{
	 @Override
		public void location(String l) {
			System.out.println("Manali located in  : "+l);
		}
	 @Override
		public void famousFor(String f) {
			System.out.println("Manali famousFor: "+f);
		}
}
class Mussoorie extends Hillstation{
	@Override
			public void location(String l) {
				System.out.println("Mussoorie located in  : "+l);
			}
	@Override
			public void famousFor(String f) {
				System.out.println("Mussoorie famousFor: "+f);
			}
}
class Gulmarg extends Hillstation{
	@Override
	public void location(String l) {
		System.out.println("Gulmarg located in  : "+l);
	}
	@Override
	public void famousFor(String f) {
		System.out.println("Gulmarg famousFor: "+f);
	}
	
}

public class Hillstation {
	  public void location(String l) {
	     	System.out.println("location : "+l);
        	}
	   
	public void famousFor(String f) {
	     	System.out.println("famousFor: "+f);
	        }
	 public static void main(String[] args) {
			// TODO Auto-generated method stub
			Hillstation hill = new Hillstation();
			hill.location("Manali,Mussoorie,Gulmarg");
			hill.famousFor("nature beauty");
			Hillstation m = new Manali();
			m.location("Himachal Pradesh");
			m.famousFor("hills and  winter sports");
			Hillstation mu=new Mussoorie();
			mu.location("Uttarakhand");
			mu.famousFor("hills and waterfalls");
			Hillstation g=new Gulmarg();
			g.location("jammu and kasmir");
			g.famousFor("lake and nature brauty");
		}


}
	
