package com.abstraction;

public class circle extends shape {
	
	 
	@Override
	void area() {
		// TODO Auto-generated method stub
		      int r =3;
			double area_of_circle =3.14*r*r;
			System.out.println(area_of_circle);
			
			
		
	}
	public static void main(String[] args) {
		 shape s = new circle();
		 s.area();
		 
	 }
}
