package com.abstraction;

public interface bike1 {
     void run();
     void avg();
     void engine();
}
