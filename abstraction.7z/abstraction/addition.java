package com.abstraction;

public interface addition {
 void addition(int a,int b);
}
