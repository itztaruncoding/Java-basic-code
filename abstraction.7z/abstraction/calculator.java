package com.abstraction;
import java.util.Scanner;
public class calculator implements multi,addition,sub,div {
	@Override
	public void div(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a*b);
	}
	@Override
	public void sub(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b);
	}
	@Override
	public void addition(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
	}
	@Override
	public void multi(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a/b);
	}
	
	public static void main(String[] args) {
		multi m = new  calculator();
		addition a = new  calculator();
		div d = new  calculator();
		sub s = new  calculator();
		m.multi(3,5 );
		a.addition(3, 5);
		d.div(3, 5);
		s.sub(4, 5);
	}

}

