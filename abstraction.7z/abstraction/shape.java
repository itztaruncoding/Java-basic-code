package com.abstraction;

public abstract class shape {
       
	shape(){
		System.out.println("hello in shape world");
	}
	abstract void area();
}
