package com.abstraction;

public interface sub {
	void sub(int a,int b);
	

}
