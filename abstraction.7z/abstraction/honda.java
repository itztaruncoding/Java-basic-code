package com.abstraction;

public class honda implements bike1,car {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("hello run");
	}

	@Override
	public void avg() {
		// TODO Auto-generated method stub
		System.out.println("hello avg");
	}

	@Override
	public void engine() {
		// TODO Auto-generated method stub
		System.out.println("hello engine");
	}

	@Override
	public void number() {
		// TODO Auto-generated method stub
		System.out.println("hello car");
		
	}
	public static void main(String[] args) {
		 bike1 s = new honda();
		 car c = new honda();
		 s.run();
		 s.avg();
		 s.engine();
		 c.number();
		 
	 }
   
}
