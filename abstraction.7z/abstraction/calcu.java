package com.abstraction;

public class calcu {

}
