package com.abstraction;

public interface multi  {
	void multi(int a,int b);

}
