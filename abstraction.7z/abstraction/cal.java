package com.abstraction;

public interface cal {
	void add();
	void sub();
	void div();
    void multi();
}
