package com.abstraction;

public interface div  {
	void div(int a,int b);

}
