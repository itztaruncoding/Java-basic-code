package com.abstraction;

public interface car {
   void number();
}
