package String;

public class string_bul {
	public void main (String args[]) {
		StringBuilder s1 = new StringBuilder();
		s1.append("hello");
		System.out.println(s1);
		
		
		s1.insert(3, " world");  
	}

}
