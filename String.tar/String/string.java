package String;

public class string {
	public static void main(String args[]) {
		String data1="java";
		String data2="python";
		String data3=new String("c++");
		boolean result=data1.equals(data3);
		
		System.out.println(result);
		System.out.println(data1.length());
		System.out.println(data1.substring(3));
		System.out.println(data1.join(data3,"hello java"));
		System.out.println(data1.contains(data3));
		System.out.println(data1.indexOf("a"));
		System.out.println(data1.split(data1));
	}

}
