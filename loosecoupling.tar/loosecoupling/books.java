package loosecoupling;

public class books implements library1{
             public void read() {
            	 System.out.println("reading books");
             }
}
