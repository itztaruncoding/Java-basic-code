package loosecoupling;

public interface library1 {
	void read();

}
