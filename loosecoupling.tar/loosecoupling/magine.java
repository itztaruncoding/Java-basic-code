package loosecoupling;

public class magine implements library1 {
	public void read() {
    	 System.out.println("reading magine");
     }

}
