package loosecoupling;

public class library {
	library1 l1;
	library(library1 l1){
		this.l1 =l1;
		
	}
          void librar_info() {
        	  
		
	}

}
